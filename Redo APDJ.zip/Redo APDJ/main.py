from flask import Flask, render_template, url_for, redirect, request, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, login_user, LoginManager, login_required, logout_user, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, EmailField
from wtforms.validators import InputRequired, Length, ValidationError
from flask_bcrypt import Bcrypt
import shelve

app = Flask(__name__)
db = SQLAlchemy()
bcrypt = Bcrypt(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SECRET_KEY'] = 'thisisasecretkey'
db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), nullable=False, unique=True)
    password = db.Column(db.String(20), nullable=False)
    confirm_password = db.Column(db.String(20), nullable=False)

class LoginForm(FlaskForm):
    username = StringField(validators=[InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Username"})

    password = PasswordField(validators=[InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Password"})

    submit = SubmitField("Login")

class RegisterForm(FlaskForm):
    email = EmailField(validators=[InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Email"})

    username = StringField(validators=[InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Username"})

    password = PasswordField(validators=[InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Password"})

    confirm_password = PasswordField(validators=[InputRequired(password)], render_kw={"placeholder": "Confirm Password"})

    submit = SubmitField("Register")


class ChangeForm(FlaskForm):
    change_username = StringField(validators=[InputRequired()], render_kw={"placeholder": "Change Username"})

    change_password = PasswordField(validators=[InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Change Password"})

    submit = SubmitField("Confirm")

with app.app_context():
  db.create_all()

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    form = LoginForm()
    if form.validate() and request.method == "POST":
        user=User.query.filter_by(username=form.username.data).first()
        if user and user.password==form.password.data:
            login_user(user)
            flash(f'Login successful!!')
            return redirect(url_for('dashboard'))

        else:
            flash(f'Username and password do not match. Please try again')

    return render_template('login.html', form=form)

@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    logout_user()
    flash(f'Logout successfully!!')
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if request.method == "POST":
        if form.validate_on_submit() and (form.password.data == form.confirm_password.data):
            existing_user_username = User.query.filter_by(username=form.username.data).first()
            if existing_user_username:
                flash(f"That username already exists. Please choose a different one.")

            elif form.password.data != form.confirm_password.data :
                flash(f"Confirm Password must be equal to Password")

            else:
                new_user = User(username=form.username.data, password=form.password.data, confirm_password=form.confirm_password.data)
                db.session.add(new_user)
                db.session.commit()
                return redirect(url_for('login'))
        print(bool(form.validate_on_submit()))
    


    return render_template('register.html', form=form)

@app.route('/edituser', methods=['GET', 'POST'])
@login_required
def edituser():
    form = ChangeForm()
    print("fiojfsiofjsiofjsiofjsiofjsiofjsdiofj")
    if request.method == "POST":
        print("onetwo")

        if User.query.filter_by(username=form.change_username.data).first() and form.change_username.data != current_user.username:
            flash("This username is not unique!", category="error")
        else:
            flash(current_user.password)
            current_user.username = form.change_username.data
            current_user.password = form.change_password.data
            db.session.commit()
            print(current_user.username)
            flash(current_user.password)
            return redirect(url_for('edituser'))
        print("bruh")
    print("bruh)")
    form.change_password.data = current_user.password
    return render_template('edituser.html', form=form)

@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))

if __name__ == '__main__':
    app.run(debug=True)
